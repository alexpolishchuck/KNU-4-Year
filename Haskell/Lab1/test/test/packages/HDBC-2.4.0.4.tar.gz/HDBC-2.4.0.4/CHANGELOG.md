# Changelog

#### 2.4.0.4

* Zero-prefix years when parsing dates.

#### 2.4.0.3

* Compatibility with GHC 8.8/time 1.9

#### 2.4.0.2

* Compatibility with GHC 8.2/time 1.8

#### 2.4.0.1

* Compatibility with time 1.5.
* Minor documentation fixes.


